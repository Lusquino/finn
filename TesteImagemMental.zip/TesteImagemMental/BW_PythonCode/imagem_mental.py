import wisardpkg as wp
import cv2
import numpy as np
import glob
import errno
import os
import tkinter
from wisardpkg import Synthesizer
from time import sleep

addressSize =16

ignoreZero =False

bleaching =False

verbose =False

alturaRetina=300

larguraRetina=300

def adaptaImagemRetina(img, size, padColor=255):
   '''
   This method code was developed by
      https://stackoverflow.com/users/5087436/alkasm &
      https://stackoverflow.com/users/492372/london-guy
   '''
   h, w = img.shape[:2]
   sh, sw = size

   # interpolation method
   if h > sh or w > sw: # shrinking image
      interp = cv2.INTER_AREA

   else: # stretching image
      interp = cv2.INTER_CUBIC

   # aspect ratio of image
   aspect = float(w)/h
   saspect = float(sw)/sh

   if (saspect > aspect) or ((saspect == 1) and (aspect <= 1)):  # new horizontal image
       new_h = sh
       new_w = np.round(new_h * aspect).astype(int)
       pad_horz = float(sw - new_w) / 2
       pad_left, pad_right = np.floor(pad_horz).astype(int), np.ceil(pad_horz).astype(int)
       pad_top, pad_bot = 0, 0

   elif (saspect < aspect) or ((saspect == 1) and (aspect >= 1)):  # new vertical image
      new_w = sw
      new_h = np.round(float(new_w) / aspect).astype(int)
      pad_vert = float(sh - new_h) / 2
      pad_top, pad_bot = np.floor(pad_vert).astype(int), np.ceil(pad_vert).astype(int)
      pad_left, pad_right = 0, 0

   # set pad color
   if len(img.shape) is 3 and not isinstance(padColor, (list, tuple, np.ndarray)): # color image but only one color provided
      padColor = [padColor]*3

   # scale and pad
   scaled_img = cv2.resize(img, (new_w, new_h), interpolation=interp)
   scaled_img = cv2.copyMakeBorder(scaled_img, pad_top, pad_bot, pad_left, pad_right, borderType=cv2.BORDER_CONSTANT, value=padColor)

   return scaled_img

def preparaImagemParaWiSARD(imagemCapturada):
   image_gray = cv2.cvtColor(imagemCapturada, cv2.COLOR_BGR2GRAY)
   _, inverted_image = cv2.threshold(image_gray,0, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
   _, uninverted_image = cv2.threshold(inverted_image, 0, 255, cv2.THRESH_BINARY_INV)
   try:
      _, contours, hierarchy = cv2.findContours(inverted_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
   except:
      contours, hierarchy = cv2.findContours(inverted_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
   x1, y1, w1, h1 = cv2.boundingRect(uninverted_image)
   fullSize = w1 * h1
   detected_image = uninverted_image
   if contours:
      maxSize = 1
      for contour in contours:
         x2, y2, w2, h2 = cv2.boundingRect(contour)
         if ((w2 * h2) > maxSize) and (w2<w1) and (h2<h1):
            maxSize = w2 * h2
            detected_image = uninverted_image[y2:y2 + h2, x2:x2 + w2]
   detected_image = adaptaImagemRetina(detected_image,(larguraRetina,alturaRetina))
   return detected_image

def aprendaComImagensDaPasta(label,folderName):
   print('Treinando a WiSARD com imagens da pasta: ',label,'...', end='')
   criaJanelaExibicaoImagens(larguraRetina,alturaRetina,'Imagem')
   X = []
   y = []
   formats = ['*.jpg','*.png','*.bmp']
   currentpath = os.path.dirname(os.path.abspath(__file__))
   parentpath = os.path.dirname(currentpath)
   for format in formats:
      path = os.path.join (parentpath, 'A-IMAGENS_TREINO', folderName, format)
      files = glob.glob(path)
      if files:
         for name in files:
            try:
               img = cv2.imread(name)
               imgToImput = preparaImagemParaWiSARD(img)
               cv2.imshow('Imagem',imgToImput)
               k = cv2.waitKey(10)
               input_data = [(1 if e==255 else 0) for e in imgToImput.flatten()]
               X.append(input_data)
               y.append(label)
            except IOError as exc:
               if exc.errno != errno.EISDIR:
                  raise
         wsd.train(X, y)
   cv2.destroyWindow('Imagem')
   print(': Treino Finalizado')

def criaJanelaExibicaoImagens(w,h,title):
   graphics = tkinter.Tk()
   halfScreenWidth = round(graphics.winfo_screenwidth()/2)
   halfScrennHeight = round(graphics.winfo_screenheight()/2)
   graphics.destroy()
   cv2.namedWindow(title, cv2.WINDOW_NORMAL)
   cv2.moveWindow(title,halfScreenWidth,halfScrennHeight)
   cv2.resizeWindow(title,w,h)
   k = cv2.waitKey(10)

def apresentaImagemMental(label):
   print('Criando imagem mental do/da',label,'...')
   allMentalImages = wsd.getMentalImages()
   syntheticData= Synthesizer(allMentalImages[label])
   classMentalImage = syntheticData.make()
   mentalImage = np.asarray(classMentalImage).reshape((larguraRetina,alturaRetina))
   mentalImage*=255
   mentalImage = mentalImage.astype(np.uint8)
   criaJanelaExibicaoImagens(larguraRetina,alturaRetina,'Imagem Mental')
   cv2.imshow('Imagem Mental',mentalImage)
   k=cv2.waitKey(10)
   sleep(3)
   cv2.destroyWindow('Imagem Mental')


print('Criando a WiSARD ...')
wsd = wp.Wisard(addressSize, ignoreZero=ignoreZero, verbose=verbose, bleaching=bleaching, returnConfidence=True)
print('WiSARD Criada')
aprendaComImagensDaPasta('cachorro','cachorro')
apresentaImagemMental('cachorro')

