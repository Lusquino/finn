# README HOMIE
This README contain information regarding the "per_channel" folder

## About this folder
This folder contains files with splitted between channels without block_id

## Peculiarities
Channels from 0 to 15 - These contain VT spaced by 1 unit and Reads spaced by 15 minutes
- Original Files:
    - forVictor_withchip_write_30C_read_30C_15min_0mon_100Reads.csv [0M]
    - forVictor_withchip_write_30C_read_30C_15min_1&3mon_100Reads.csv [1M] [3M]

## Useful Information
Some files might contain NaN or 0.0 values on the BEC column, these must be ignored when finding the best VT as they represent bad blocks or incorrectable erros
