# Info

Folder: 1/
	Data from: "forVictor_xgboost_write_30C_read_30C_5_hr_0&3mon_DR.csv"
	DR: 0 Months
	Opt VT: -10

Folder: 2/
	Data from: "forVictor_xgboost_write_30C_read_30C_5_hr_0&3mon_DR.csv"
	DR: 0 and 3 Months
	Opt VT: -10 and -15

Folder: 3/
	Data from: "forVictor_xgboost_write_30C_read_30C_-5_0&3mon_100hr.csv"
	DR: 0 and 3 Months
	Opt VT: -5 and -15
