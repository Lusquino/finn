#
# Uses XGBoost and treats it as a linear regression problem
#
# Mem profiling:
#   python3 /home/vcruz/.local/lib/python3.7/site-packages/mprof.py run $FILENAME
#   python3 /home/vcruz/.local/lib/python3.7/site-packages/mprof.py plot

import xgboost as xgb
import utils
from sklearn import preprocessing, model_selection
import matplotlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time

SEQ_LEN=12
BALANCING = True
NORMALIZATION = False
NORM_COLS = ['VT','BEC','Temp']
MOVING_AVERAGE = True
NUM_ROUNDS = 25
SEQ_TYPE='flat'

def flat_sequence(sequence):
    aux=[]
    for i in range(len(sequence)):
        aux.append(list(sequence[i].ravel())) #flattening

    return np.array(aux)

def process_data(filenames):
    scalers={}
    df_arr = []
    for filename in filenames:
        df_arr.append(utils.add_target_col(filename,drop=True,moving_average=MOVING_AVERAGE))


    #.counting target per df
    #utils.print_target_num(df_arr,filenames)

    #merges file and build input
    main_df = pd.concat(df_arr[:],ignore_index=True) # concats all dataframes
    main_df = utils.drop_badblocks(main_df) # needs to be done after concat to not reset index

    if(NORMALIZATION):
        main_df, scalers= utils.normalize_cols(main_df,NORM_COLS) # returns trained normalization scalers

    #creates sequences, normalizes and balances the data
    if('Block' in main_df.columns): 
        data_X,data_y = utils.preprocess_df_with_block(main_df,seq_len=SEQ_LEN,norm=NORMALIZATION,balancing=BALANCING,drop_outliers=2, model=MODEL) #TODO FIX
    else:
        data_X,data_y = utils.preprocess_df(main_df,seq_len=SEQ_LEN,balancing=BALANCING,drop_outliers=2, seq_type=SEQ_TYPE)

    print(data_X)
    #if(SEQ_LEN>1):
    #    data_X = flat_sequence(data_X)

    return data_X,data_y,scalers

def train_model(data_X, data_y):

    #Splits data
    train_x, validation_x, train_y, validation_y = model_selection.train_test_split(data_X, data_y, 
                                                        # train_size=0.7, 
                                                        test_size=0.3, 
                                                        random_state= np.random.randint(1000, size=1)[0]) 

    print(f"train data: {len(train_x)} validation: {len(validation_x)}")

    dtrain = xgb.DMatrix(train_x, label=train_y)
    dtest = xgb.DMatrix(validation_x, label=validation_y)

    #xgboost parameters
    #https://xgboost.readthedocs.io/en/latest/parameter.html
    param={}
    param['booster'] = 'gbtree' #gbtree, dart, gblinear # gbtree and dart use tree based models while gblinear uses linear functions.
    param['nthread'] = 4
    param['eval_metric'] = ['rmse','mae']
    #param['objective'] = 'reg:squarederror'
    #param['max_depth'] = 6
    #param['max_delta_step'] = 5
    #param['interaction_constraints'] = "[[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],[0,8],[0,9],[0,10],[0,11],[0,12]]"

    evallist = [(dtest, 'eval'), (dtrain, 'train')]

    #train the model // Model is in bst
    t_start = time.time()
    bst = xgb.train(param, dtrain, NUM_ROUNDS, evals=evallist)
    t_end = time.time()
    train_time = t_end - t_start
    t_start = time.time()
    ypred = bst.predict(dtest)
    t_end = time.time()
    pred_time = t_end - t_start

    hit=0
    for i in range(len(ypred)):
        hit += (abs(ypred[i]-validation_y[i]) < 2.5)
        #print(f"Prediction: {ypred[i]} | Expected: {validation_y[i]}")
    print(f"Estimated Accuracy: {hit/len(validation_y)}" )

    print(f"Rounds: {NUM_ROUNDS} | Train time:{train_time} | Pred Time:{pred_time} | Pred Per Sample:{pred_time/len(validation_y)}")

    return bst

def save_model(model):
    model_name = f"./models/xgb_reg_R{NUM_ROUNDS}_SEQ{SEQ_LEN}_BAL{int(BALANCING)}_NORM{int(NORMALIZATION)}_SMA{int(MOVING_AVERAGE)}.model"
    print(f"Saving Model: {model_name}")
    model.save_model(model_name)


def test_model(bst,filename,norm_scalers):


    df = utils.add_target_col(filename,drop=True,moving_average=True)
    df = utils.drop_badblocks(df)

    if(NORMALIZATION):
       df,scaler = utils.normalize_cols(df,NORM_COLS,scalers=norm_scalers)

    if('Block' in df.columns):
        test_X,test_y = utils.preprocess_df_with_block(df,seq_len=SEQ_LEN,balancing=False,drop_outliers=0, model=MODEL)
    else:
        test_X,test_y = utils.preprocess_df(df,seq_len=SEQ_LEN,balancing=False,drop_outliers=0, seq_type=SEQ_TYPE)

    #if(SEQ_LEN>1):
    #    test_X = flat_sequence(test_X)

    dtest2 = xgb.DMatrix(test_X, label=test_y)
    ypred = bst.predict(dtest2)
    hit=0
    for i in range(len(ypred)):
        hit += (abs(ypred[i]-test_y[i]) < 2.5)

    print(f"Estimated Accuracy: {hit/len(test_y)}" )


#---------------------------------------------
#.max files
#filenames = ["./data/1_100h_BER_VT_temp.csv","./data/2_100h_BER_VT_temp.csv","./data/3_100h_BER_VT_temp.csv","./data/4_214h_BER_VT_temp.csv","./data/5_130h_BER_VT_temp.csv"] #.all files
#filenames = ["./data/with_block/3_100h_BER_VT_temp_block_PE.csv","./data/with_block/4_214h_BER_VT_temp_block_PE.csv","./data/with_block/5_130h_BER_VT_temp_block_PE.csv"] #.data with block id and PE count #.data with block id and PE count
#.per channel files
common = "_BER_VT_temp.csv"
train_filenames=[]
test_filenames = []
dr_m = [0,1,3,12]
for m in dr_m:
    train_filenames += [ f"./data/per_channel/DR-{m}months/{ch}{common}" for ch in range(15)]
    test_filenames += [f"./data/per_channel/DR-{m}months/15{common}"]
    #filenames += [ f"./data/with_block/per_channel/DR-{m}months/{ch}_BER_VT_temp_block_PE.csv" for ch in range(15)]

#----------------------------------------------

train_x, train_y, scalers  = process_data(train_filenames)

bst = train_model(train_x, train_y)
#save_model(bst)

#.Testing Set
for f in test_filenames:
    print(f"Test Set: {f}")
    test_model(bst,f,scalers)



#.plotting
#xgb.plot_tree(bst)
#aux = xgb.plot_importance(bst)
#aux.figure.savefig('./plots/importance_withblock.png')
#plt.show()

'''
fig = plt.figure(figsize=[20,5])
ypred = ypred[:50]
validation_y = validation_y[:50]
plt.grid(True)
plt.plot(ypred,label="prediction")
plt.plot(validation_y,label="ground_truth")
#plt.scatter(list(range(len(ypred))),ypred,label="prediction")
#plt.scatter(list(range(len(validation_y))),validation_y,label="ground_truth")
plt.legend(loc=2)
#fig.savefig("temp.png", bbox_inches='tight')
plt.show()
'''