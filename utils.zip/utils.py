import pandas as pd
from sklearn import preprocessing, compose
from sklearn.externals.joblib import dump
from collections import deque
import numpy as np
import random
import math
import category_encoders as ce

#TODO Feed Multiple BEC on the sample feature tuple
    #TODO - Use BECs for all the blocks each as an independent feature

#TODO Set temperature from value to Low-Mid-High
#!https://medium.com/analytics-vidhya/feature-preprocessing-for-numerical-data-the-most-important-step-e9ed76151298
#!https://towardsdatascience.com/smarter-ways-to-encode-categorical-data-for-machine-learning-part-1-of-3-6dca2f71b159

def print_target_num(arr_df,filenames):
    i=0
    #.counting target per df
    print("Total number of Optimal VTs per file")
    for df in arr_df:
        #print("File: {}".format(filenames[i]))
        print(f"File: {filenames[i]}")
        aux = df['target'].value_counts()
        for key,val in aux.iteritems():
            #print("{} -> {}".format(key,val))
            print(f"{key} -> {val}")
        i+=1

#.prints the entire dataframe
def print_df(df):
    with pd.option_context('display.max_rows', None, 'display.max_columns', None):  # more options can be specified also
        print(df)


#---------------------------------------------------------------------------------------------
#.Drops badblocks and uncorrectables such as BEC = 0.0 or NaNs
def drop_badblocks(df):
    df.dropna(inplace=True) #Droping Uncorrectables (BEC = NAN)
    new_df = df[df['BEC'] != 0] # Dropping Bad Blocks ( BEC = 0)

    return new_df

#.Drops VT Rows of dataframe
def drop_vt_rows(df):
    #dropping VTs
    vts = df['VT'].unique() #all available VTs
    for i in range(len(vts)):
        if(vts[i] > 5 ): #!dropping VT rows bigger than 5
            df = df[df['VT'] != vts[i]]
    
    return df

#.Normalizing PEs via bucketing
def bucketing_PE(val):
    new_val = ""
    if(val <= 100):
        new_val = 'BOL'
    elif(val <= 3500):
        new_val = 'MOL'
    else: #7000
        new_val = 'EOL'

    return new_val

#.Normalizes each feature separetely
def normalize_cols(df,norm_cols,scalers={}):

    new_scaler = {}
    columns = df.columns
    #not_normalizable = ['Read','BOL','EOL','MOL'] # features that should not be normalized

    for col in columns:
        if(col in norm_cols): # normalize only the correct features
            df_col_reshaped = df[col].values.reshape(-1, 1)

            if(not scalers): # if empty
                scaler = preprocessing.StandardScaler()
                df[col] = scaler.fit_transform(df_col_reshaped)
                new_scaler[col] = scaler
            else:
                scaler = scalers[col]
                df[col] = scaler.transform(df_col_reshaped)
                #dump(scaler, f'./models/norm_std_scaler_f{col}.bin', compress=True) #pickle dumping info about scaler
        #print(df.head())

    return df,new_scaler

#.receives series of data as ( sequence[], target ) and balances according to the least frequent target
def under_balancing(data):
    # count number of targets
    target_count = {}
    for seq,target in data:
        if(not str(target) in target_count):
            target_count[str(target)] = 1
        else:
            target_count[str(target)]+=1
    
    lower =  min(target_count.values())
    print(f"Balancing with size {lower}")

    #underbalancing data
    output_data = []
    for seq,target in data:
        if(target_count[str(target)] > lower):
            target_count[str(target)]-=1
        else:
            output_data.append([seq,target])


    random.shuffle(output_data)

    return output_data

#.finds best target using moving average
def find_target_avbec(df,num_max_reads,num_vts): 

    window_size = 10
    #if there is block column
    if('Block' in df.columns):
        num_max_block = df['Block'].max()
        jump_size = df.at[1,'Block'] - df.at[0,'Block']
        num_blocks = int((num_max_block/jump_size) +1)
    else:
        num_blocks = 1
    
    quantity_per_vt = int(num_max_reads*num_blocks)
    
    vts = df['VT'].unique()
    bec = df['BEC'].values  
    target = []

    #quantity_per_vt = int(len(bec)/num_vts) #int(len(df.index)/df['VT'].nunique())
 
    def average(arr,end,window_size):
        s=0
        count=0
        index = end
        while(count<window_size):
            s += arr[index]
            count+=1
            index = end-(count*num_blocks) # jumps from read to read

        return s/count

    def exp_average(arr,end,window_size,count=1):
        smoothing = 2
        time_period = window_size
        if(count==window_size): #final
            return arr[end]
        else:
            previous_end = end-(count*num_blocks)
            value_today = arr[end] #current value
            previous_exp_average = exp_average(arr,previous_end,window_size,count+1) # previous exponential average value 
            exponential_average = value_today * (smoothing/(1+time_period)) + previous_exp_average*(1-(smoothing/(1+time_period))) # weighted 
            #exponential_average = (2 * (value_today - previous_exp_average)) + previous_exp_average
            return exponential_average

    read_num = 0
    for i in range(quantity_per_vt):
        read_num = read_num+1 if (i % num_blocks) == 0 else read_num #counting reads (time series)
        slide_size = window_size if (read_num>window_size) else read_num

        best_index = i
        #begin = best_index-(num_blocks*window_size)
        best_avbec = average(bec,i,slide_size) #moving average of the last window values
        #!best_avbec = exp_average(bec,i,slide_size) #moving average of the last window values
        for k in range(1,num_vts): #number of vts
            current_index = i+((quantity_per_vt)*k)

            #print(f"Best BEC: {best_bec} | Best Index:{best_index} | Best VT: {df.at[best_index,'VT']} || Current BEC: {bec[current_index]} | Current Index: {current_index} | Current VT: {df.at[current_index,'VT']}")
            if (not math.isnan(bec[current_index])) and (bec[current_index]!=0): #if not a Uncorrectable(NaN) or Bad Block(0.0)
                current_avbec = average(bec,current_index,slide_size) # moving average of the last window values
                #!current_avbec = exp_average(bec,current_index,slide_size) # moving average of the last window values
                if (best_avbec > current_avbec):
                    best_avbec = current_avbec
                    best_index = current_index # saves index with best(lowest) BEC

        if(math.isnan(bec[best_index])) or (bec[best_index]==0): # in case all values were 0 or NaN
            best_vt = math.nan
        else:
            best_vt = df.at[best_index,'VT']
        target.append(float(best_vt))

    return target

#.finds best target for each read
def find_target(df,num_max_reads,num_vts): 

    bec = df['BEC'].values 
    target = []

    quantity_per_vt = int(len(bec)/num_vts) # how many combinations of (Read,Block) there are per VT

    #print(f"MAX Block: {num_max_block} | Jump Size: {jump_size} | Number of Blocks: {num_blocks} | Quantity per VT: {quantity_per_vt}")
    for i in range(quantity_per_vt):  
        best_bec = bec[i]
        best_index = i
        for k in range(num_vts):
            current_index = i+(quantity_per_vt*k)
            #print(f"Best BEC: {best_bec} | Best Index:{best_index} | Best VT: {df.at[best_index,'VT']} || Current BEC: {bec[current_index]} | Current Index: {current_index} | Current VT: {df.at[current_index,'VT']}")
            if (not math.isnan(bec[current_index])) and (bec[current_index]!=0): #if not a Uncorrectable(NaN) or Bad Block(0.0)
                if (best_bec > bec[current_index]):
                    best_bec = bec[current_index]
                    best_index = current_index # saves index with the best(lowest) BEC
        
        if(math.isnan(bec[best_index])) or (bec[best_index]==0): # in case all values were 0 or NaN
            best_vt = math.nan
        else:
            best_vt = df.at[best_index,'VT']
        target.append(float(best_vt))
    
    return target

#.Takes original File and adds target col
def add_target_col(filename,drop=True,moving_average=False):
    original_df = pd.read_csv(filename)

    cols = original_df.columns

    #Renaming BEC column
    original_df.rename(columns={"nanmax_of_BEC": "BEC"}, inplace=True)

    #Dropping VTs
    if(drop):
        original_df = drop_vt_rows(original_df)

    vt = original_df["VT"].values
    read_num = original_df["Read"].values
    max_read = original_df["Read"].max() # gets maximum number of reads
    bec = original_df["BEC"].values
    vt_labels = original_df['VT'].unique()
    num_vts = len(vt_labels) #original_df['VT'].nunique() # gets number of vt tested

    if(moving_average):
        target = find_target_avbec(original_df,max_read,num_vts) # target is organized by read num id
    else:
        target = find_target(original_df,max_read,num_vts) # target is organized by read num id
 
    label=[0 for i in range(len(original_df.index))] #size of total number of rows
    for i in range(len(read_num)):
        label[i] = target[i %len(target)]

    original_df.insert(loc=len(original_df.columns),column='target',value=label,allow_duplicates= False)

    #bucketing and one-hotting pe cycle count
    if('PE' in cols):
        pe_labels = original_df['PE'].apply(bucketing_PE) #bucketing
        one_hot = pd.get_dummies(pe_labels) #one-hot enconding
        original_df = original_df.join(one_hot)
        original_df = original_df.drop(['PE'],1)

    #!temp
    '''
    sma = []
    for vt in original_df['VT'].unique():
        df_aux = original_df[original_df['VT']==vt]
        #df_aux = df_aux[df_aux['BEC']!=0]
        sma+=df_aux['BEC'].rolling(window=5).mean().tolist()
    original_df.insert(loc=len(original_df.columns),column='bec_sma',value=sma,allow_duplicates= False)
    '''

    #original_df.dropna(inplace=True) #Droping Uncorrectables (BEC = NAN)
    #original_df = original_df[original_df['BEC'] != 0] # Dropping Bad Blocks ( BEC = 0)

    return original_df


#---------------------------------------------------------------------------------------------
#.creates sequences
def create_sequences(df,targets,seq_len=12, outliers=[], seq_type='flat'):
    sequential_data = []
    prev_reads = deque(maxlen=seq_len)
    seq_targets = deque(maxlen=seq_len)
    
    target = targets.values
    data = df.values

    if(seq_len>1):
        if(seq_type=='flat'):
            vt=0
            for i in range(len(data)):
                if (data[i][0]!=vt):
                    prev_reads.clear()

                bec = data[i][1]
                ignore = ((bec==0) or (math.isnan(bec))) # ignoring bad blocks and uncorrectables

                if(ignore) or (target[i] in outliers):
                    continue

                vt = data[i][0]
                prev_reads.append(bec)
                seq_targets.append(target[i])
                if(len(prev_reads)==seq_len):
                    arr = np.delete(data[i],1)
                    aux= np.concatenate((arr,prev_reads))
                    t = max(seq_targets,key=seq_targets.count)  #gets target that appears the most
                    #sequential_data.append([aux,float(t)])      
                    sequential_data.append([aux,float(target[i])])

        elif (seq_type=='matrix'): # creates sequence as 2D Matrix
            for i in range(len(data)):
                
                bec = data[i][1]
                #ignore = ((bec==0) or (math.isnan(bec))) # ignoring bad blocks and uncorrectables

                if(target[i] in outliers): #or (ignore):
                    continue

                if(len(prev_reads) > 0): #disables sequences with different VTs
                    if (data[i][0]!=prev_reads[-1][0]): # if VTs are different        
                        prev_reads.clear()
                
                prev_reads.append(data[i]) #gets row of df ( features )
                #prev_reads.append([data[i][0],data[i][2]])
                #seq_targets.append(target[i])
                if(len(prev_reads)==seq_len): 
                    #t = max(seq_targets,key=seq_targets.count)  #gets target that appears the most
                    #sequential_data.append([np.array(prev_reads),int(t)])          
                    sequential_data.append([np.array(prev_reads),int(target[i])])


    else:
        for i in range(len(data)):
            bec = data[i][1]
            ignore = ((bec==0) or (math.isnan(bec))) # ignoring bad blocks and uncorrectables
            if(ignore) or (target[i] in outliers):
                continue
            sequential_data.append([np.array(data[i]),float(target[i])])
        
    
    random.shuffle(sequential_data)

    return sequential_data

#.preprocess the dataframe from the original file (creates sequences and balances them)
def preprocess_df(df,seq_len=0, balancing=False, drop_outliers=0, seq_type='flat', scalers={}):

    df = df.drop(["Read"],1) #Dropping Read feature
    if('Temp' in df.columns):
        df = df.drop(['Temp'],1) #!Dropping temperature

    targets = df.pop('target')
    t_count = targets.value_counts()
    print(f"Total amount: \n {t_count}")

    outliers=[]
    if(drop_outliers > 0):
        for i in range(drop_outliers): #Dropping the least frequent targets
            min_val = t_count.idxmin()
            outliers.append(min_val)
            t_count = t_count[t_count.index!=min_val]
        
        print(f"Dropping {outliers}")


    sequential_data = create_sequences(df,targets,seq_len=seq_len, outliers=outliers, seq_type=seq_type)

    #balacing according to target (Undersampling)
    if(balancing):
        sequential_data = under_balancing(sequential_data)
    

    #formats for tensorflow
    X=[]
    y=[]
    for seq, target in sequential_data:  # going over our new sequential data
        X.append(seq)  # X is the sequences
        y.append(target)  # y is the targets/labels

    return np.array(X), np.array(y)


#TODO Update
#TODO merge _with_block functions with their counter part
#!not working due to NaN and BEC=0.0 for Normalized data
def create_sequences_with_block(df,targets,num_blocks,seq_len=5,outliers=[],model='rnn'):
    
    sequential_data = []
    
    target = targets.values
    data = df.values
    drop_outliers = len(outliers) > 0

    if(seq_len>1):
        prev_reads = deque(maxlen=seq_len)
        #seq_targets = deque(maxlen=seq_len)
        #jumps between reads with same block_id to create sequence
        for i in range(num_blocks):
            k=0
            current_index=i
            while(current_index < len(data)):
                #print(data[current_index])
                bec = data[current_index][1]

                #!does work with normalized data
                ignore = ((bec==0) or (math.isnan(bec))) # ignoring bad blocks and uncorrectables

                if(ignore) or (target[current_index] in outliers): #!removes target outliers for balancing
                    k+=1
                    current_index = i+(num_blocks*k)
                    continue
                

                if(len(prev_reads) > 0): #disables sequences with different VTs
                    if (vt!=data[current_index][0]): # if previous vt is different, clear sequence       
                        prev_reads.clear()
                
                vt=data[current_index][0]

                if(model=='xgb'):
                    prev_reads.append(bec)
                    if(len(prev_reads)==seq_len):
                        arr = np.delete(data[i],1) # deletes bec
                        aux= np.concatenate((arr,prev_reads))
                        sequential_data.append([aux,int(target[current_index])]) 

                else:
                    prev_reads.append(data[current_index])
                    #seq_targets.append(target[current_index])
                    if(len(prev_reads)==seq_len):
                        #t = max(seq_targets,key=seq_targets.count)  #gets target that appears the most
                        #sequential_data.append([np.array(prev_reads),int(t)])                
                        sequential_data.append([np.array(prev_reads),int(target[current_index])])
                k+=1
                current_index = i+(num_blocks*k)
    else:
        for i in range(len(data)):

            bec = data[current_index][1]
            ignore = ((bec==0) or (math.isnan(bec))) # ignoring bad blocks and uncorrectables

            if(ignore) or (target[i] in outliers):
                continue
            sequential_data.append([np.array(data[i]),float(target[i])])

    random.shuffle(sequential_data)

    return sequential_data

#!Working but Too slow
def create_sequences_with_block2(df,targets,seq_len=5,outliers=[],model='rnn'):
    
    sequential_data = []
    
    #target = targets.values
    #data = df.values
    drop_outliers = len(outliers) > 0

    if(seq_len>1):
        prev_reads = deque(maxlen=seq_len)
        #seq_targets = deque(maxlen=seq_len)
        #jumps between reads with same block_id to create sequence
        for blockid in df['Block'].unique():
            aux_block = df[df['Block']== blockid].index

            for current_index in aux_block:
                #print(df.loc[[current_index]])

                bec = df.at[current_index,'BEC']

                ignore = ((bec==0) or (math.isnan(bec))) # ignoring bad blocks and uncorrectables

                if(ignore) or (targets.at[current_index] in outliers): #!removes target outliers for balancing
                    continue
                

                if(len(prev_reads) > 0): #disables sequences with different VTs
                    if (vt!=df.at[current_index,'VT']): # if previous vt is different, clear sequence       
                        prev_reads.clear()
                
                vt=df.at[current_index,'VT']

                data = df.loc[[current_index]].values
                data = np.delete(data,1) #!deletes Block

                if(model=='xgb'):
                    prev_reads.append(bec)
                    if(len(prev_reads)==seq_len):
                        arr = np.delete(data,2) #deletes BEC since it is in prev_reads
                        aux= np.concatenate((arr,prev_reads))
                        sequential_data.append([aux,int(targets.at[current_index])]) 

                else:
                    prev_reads.append(data)
                    #seq_targets.append(target[current_index])
                    if(len(prev_reads)==seq_len):
                        #t = max(seq_targets,key=seq_targets.count)  #gets target that appears the most
                        #sequential_data.append([np.array(prev_reads),int(t)])                
                        sequential_data.append([np.array(prev_reads),int(targets.at[current_index])])

    else:
        data = df.drop(['Block'],1).values
        target = targets.values
        for i in range(len(data)):

            bec = data[i][1]
            ignore = ((bec==0) or (math.isnan(bec))) # ignoring bad blocks and uncorrectables

            if(ignore) or (target[i] in outliers):
                continue
            sequential_data.append([np.array(data[i]),float(target[i])])

    random.shuffle(sequential_data)

    return sequential_data


#.preprocess the dataframe from the original file and creates sequences taking block id into consideration

def preprocess_df_with_block(df,seq_len=0,balancing=False,drop_outliers=0,model='rnn'):

    df = df.drop(["Read"],1)
    outliers=[]
    t_count = df['target'].value_counts()
    print("Total amount: \n{}".format(t_count))


    targets = df.pop('target')
    num_blocks = df['Block'].nunique()
    t_unique_values= targets.unique()

    if(drop_outliers > 0):
        for i in range(drop_outliers): #Droping the least N frequent Target VTs
            min_val = t_count.idxmin()
            outliers.append(min_val)
            t_count = t_count[t_count.index!=min_val]
        print("Dropping {}".format(outliers))

        for val in outliers:
            t_unique_values = t_unique_values[t_unique_values != val]


    df = df.drop(['Block','Temp'],1) #!Dropping Block and Temp


    #sequential_data = create_sequences_with_block(df,targets,seq_len=seq_len,outliers=outliers,model=model)
    sequential_data = create_sequences_with_block(df,targets,num_blocks,seq_len=seq_len,outliers=outliers,model=model)


    #balacing according to target (undersampling)
    if(balancing):
        seq_per_target = [[] for i in range(len(t_unique_values))]
        for seq, target in sequential_data: 
            for i in range(len(t_unique_values)):
                if t_unique_values[i] == target:
                    seq_per_target[i].append([seq, target]) #divides sequential array according to their target data   

        lower = len(seq_per_target[0])
        for i in range(1,len(seq_per_target)):
            size = len(seq_per_target[i])
            if(size > 0):
                lower = min(size,lower)
                
        #lower = min([len(seq_per_target[i]) for i in range(len(seq_per_target))])
        print(f"Balancing with size {lower}")
        for i in range(len(seq_per_target)):
            seq_per_target[i] = seq_per_target[i][:lower]
        
        sequential_data = []
        for i in range(len(seq_per_target)):
            sequential_data = sequential_data + seq_per_target[i]
        random.shuffle(sequential_data)
    
    
    #formats for tensorflow
    X=[]
    y=[]
    for seq, target in sequential_data:  # going over our new sequential data
        X.append(seq)  # X is the sequences
        y.append(target)  # y is the targets/labels

    return np.array(X), np.array(y)
