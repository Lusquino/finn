#
# Uses Regression WiSARD and treats it as a linear regression problem
#
# Mem profiling:
#   python3 /home/vcruz/.local/lib/python3.7/site-packages/mprof.py run $FILENAME
#    python3 /home/vcruz/.local/lib/python3.7/site-packages/mprof.py plot

import utils
from sklearn import preprocessing, model_selection
import numpy as np
import pandas as pd
import time
import math
import lib.pybind_wisard.wisardmodule as wis
import resource


SEQ_LEN=12
BALANCING = True
NORMALIZATION = False
MOVING_AVERAGE = True
RADDRSIZE = 28
THERMOMETER_SIZE = 240
USED_FEATURES =['VT','BEC']#,'Temp']
SEQ_TYPE='matrix'


def memory_limit():
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    resource.setrlimit(resource.RLIMIT_AS, (get_memory() * 1024 / 2, hard))

def get_memory():
    with open('/proc/meminfo', 'r') as mem:
        free_memory = 0
        for i in mem:
            sline = i.split()
            if str(sline[0]) in ('MemFree:', 'Buffers:', 'Cached:'):
                free_memory += int(sline[1])
    return free_memory

def thermometer(feature,len_min,len_max,therm_size):

    #print data, self.min, self.max, self.interval
    interval = len_max - len_min
    if interval != 0.0:
        bits_activated = int(math.ceil(((float(feature) - len_min)/ interval ) * therm_size))        
        if bits_activated > therm_size:
            #binarray = np.ones(therm_size, dtype=bool)
            binarray = "1"*therm_size
        else:
            binarray = ("1"*bits_activated)+("0"* (therm_size-bits_activated)) #np.zeros(therm_size, dtype=bool)

            #for i in range(bits_activated):
                #binarray[i] = 1
    else:
        binarray = "1"*therm_size #np.ones(therm_size, dtype=bool)

    return binarray

##--------------------------------------------------------------------------------
#memory_limit() # !Limitates maximun memory usage to half

#.max files
#filenames = ["./data/1_100h_BER_VT_temp.csv","./data/2_100h_BER_VT_temp.csv","./data/3_100h_BER_VT_temp.csv","./data/4_214h_BER_VT_temp.csv","./data/5_130h_BER_VT_temp.csv"] #.all files
#.per channel files
common = "_BER_VT_temp.csv"
filenames=[]
dr_m = [0,1,3,12]
for m in dr_m:
    filenames += [ f"./data/per_channel/DR-{m}months/{ch}{common}" for ch in range(15)]

df_arr = []
for filename in filenames:
    df_arr.append(utils.add_target_col(filename,drop=True,moving_average=MOVING_AVERAGE))

#.counting target per df
utils.print_target_num(df_arr,filenames)


#merges file and build input
main_df = pd.concat(df_arr[:],ignore_index=True) # concats all dataframes
main_df = utils.drop_badblocks(main_df) # dropping bad blocks

max_vt = main_df['VT'].max()
main_df['VT'] = main_df['VT'].apply(lambda a: abs(a)+max_vt if a<0 else a) #removes negative VTs for thermometer
#utils.print_df(main_df)

feature_therm_len = {}
for f in USED_FEATURES:
    min_val = main_df[f].min()
    max_val = main_df[f].max()
    feature_therm_len[f] = (min_val,max_val)


model='rnn' # to build sequences like the ones in RNN
#creates sequences, normalizes and balances the data
data_X,data_y = utils.preprocess_df(main_df,seq_len=SEQ_LEN,balancing=BALANCING,drop_outliers=2, seq_type=SEQ_TYPE)

print(data_X)

#flatten sequences
if(SEQ_LEN>1) and (SEQ_TYPE=='matrix'):
    aux=[]
    for i in range(len(data_X)):
        aux.append(list(data_X[i].ravel())) #flattening
    data_X=np.array(aux)

sequence_features = []
if(model=='rnn'):
    for i in range(0,len(data_X[0]),len(USED_FEATURES)):
        sequence_features+= USED_FEATURES
elif(model=='xgb'):
    for i in range(len(data_X[0])):
        if(i>len(USED_FEATURES)-2):
            sequence_features += ['BEC']
        else:
            if(i>0):
                sequence_features += [USED_FEATURES[i+1]]
            else:
                sequence_features += [USED_FEATURES[i]]

#Splits data
train_x, validation_x, train_y, validation_y = model_selection.train_test_split(data_X, data_y, 
                                                    # train_size=0.7, 
                                                      test_size=0.3, 
                                                      random_state= np.random.randint(1000, size=1)[0]) 

print(f"train data: {len(train_x)} validation: {len(validation_x)}")

#----------------------------------------------------------------
#Binarizes the data using thermometer
def convert_to_bin(arr,sequence_features):
    binarr = []
    feat_therm_size = int(math.floor(THERMOMETER_SIZE/len(arr[0]))) #thermometer size per feature
    for feat_tuple in arr:
        binary_feature=""
        for i in range(len(feat_tuple)):
            therm_len_min,therm_len_max = feature_therm_len[sequence_features[i]]

            feature = feat_tuple[i]
            #feature_size = len(bin(int(feature)))-2
            binary_feature+=thermometer(feature,therm_len_min,therm_len_max,feat_therm_size)

        #print("Size: {}  Feature: {} | Therm: {}".format(feat_therm_size,feat_tuple,binary_feature))
        binarr.append(binary_feature)
    
    return binarr

train_x = convert_to_bin(train_x,sequence_features)
train_y= train_y.astype(int).tolist()

validation_x  = convert_to_bin(validation_x,sequence_features)
validation_y = validation_y.astype(int).tolist()


#.Initializing WiSARD
num_rams = int((len(train_x[0])/RADDRSIZE)) #int(THERMOMETER_SIZE/RADDRSIZE)
print(f"Therm Size: {len(train_x[0])}")

w = wis.RegWiSARD(RADDRSIZE,num_rams)

#trains
t_start = time.time()
bst = w.fit(train_x,train_y,len(train_y))
t_end = time.time()
train_time = t_end - t_start
#w.print_content()
#validation
t_start = time.time()
ypred = w.evaluate(validation_x,validation_y,len(validation_y))
mae = w.get_metric_score()
t_end = time.time()
pred_time = t_end - t_start

#print(ypred)
print("MAE: {}".format(mae))
print("Train time:{} | Pred Time:{} | Pred Per Sample:{}".format(train_time,pred_time,pred_time/len(validation_y)))